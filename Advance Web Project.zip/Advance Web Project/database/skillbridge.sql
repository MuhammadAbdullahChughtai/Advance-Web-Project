-- =====================================================
-- SkillBridge  |  Student Freelance Marketplace
-- Advanced Web Programming - Assignment 2
-- Import this file in phpMyAdmin (or: mysql -u root < skillbridge.sql)
-- =====================================================

CREATE DATABASE IF NOT EXISTS skillbridge
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE skillbridge;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS contact_messages, saved_jobs, applications, jobs, freelancer_profiles, categories, users;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. USERS (admin / client / freelancer) ---------------
CREATE TABLE users (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name     VARCHAR(100) NOT NULL,
  email         VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('admin','client','freelancer') NOT NULL DEFAULT 'freelancer',
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. CATEGORIES ----------------------------------------
CREATE TABLE categories (
  id    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name  VARCHAR(80) NOT NULL UNIQUE,
  slug  VARCHAR(40) NOT NULL UNIQUE,
  icon  VARCHAR(40) NOT NULL DEFAULT 'bi-briefcase'
) ENGINE=InnoDB;

-- 3. FREELANCER PROFILES (1 user : 1 profile) ----------
CREATE TABLE freelancer_profiles (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id        INT UNSIGNED NOT NULL UNIQUE,
  category_id    INT UNSIGNED NOT NULL,
  headline       VARCHAR(100) NOT NULL,
  bio            VARCHAR(300) NOT NULL,
  skills         VARCHAR(200) NOT NULL,
  rating         DECIMAL(2,1) NOT NULL DEFAULT 0.0,
  reviews_count  INT UNSIGNED NOT NULL DEFAULT 0,
  CONSTRAINT fk_prof_user FOREIGN KEY (user_id)     REFERENCES users(id)      ON DELETE CASCADE,
  CONSTRAINT fk_prof_cat  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT,
  CONSTRAINT chk_rating CHECK (rating BETWEEN 0 AND 5)
) ENGINE=InnoDB;

-- 4. JOBS (posted by clients) --------------------------
CREATE TABLE jobs (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  client_id    INT UNSIGNED NOT NULL,
  category_id  INT UNSIGNED NOT NULL,
  title        VARCHAR(120) NOT NULL,
  description  TEXT NOT NULL,
  skills       VARCHAR(200) NOT NULL,
  budget       INT UNSIGNED NOT NULL,
  status       ENUM('open','closed') NOT NULL DEFAULT 'open',
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_job_client FOREIGN KEY (client_id)   REFERENCES users(id)      ON DELETE CASCADE,
  CONSTRAINT fk_job_cat    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT,
  CONSTRAINT chk_budget CHECK (budget > 0)
) ENGINE=InnoDB;

-- 5. APPLICATIONS (freelancer -> job, many-to-many) ----
CREATE TABLE applications (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  job_id         INT UNSIGNED NOT NULL,
  freelancer_id  INT UNSIGNED NOT NULL,
  cover_letter   TEXT NOT NULL,
  status         ENUM('pending','accepted','rejected') NOT NULL DEFAULT 'pending',
  applied_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_job_freelancer (job_id, freelancer_id),
  CONSTRAINT fk_app_job  FOREIGN KEY (job_id)        REFERENCES jobs(id)  ON DELETE CASCADE,
  CONSTRAINT fk_app_user FOREIGN KEY (freelancer_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 6. SAVED JOBS (the heart button) ----------------------
CREATE TABLE saved_jobs (
  user_id  INT UNSIGNED NOT NULL,
  job_id   INT UNSIGNED NOT NULL,
  saved_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, job_id),
  CONSTRAINT fk_save_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_save_job  FOREIGN KEY (job_id)  REFERENCES jobs(id)  ON DELETE CASCADE
) ENGINE=InnoDB;

-- 7. CONTACT MESSAGES ----------------------------------
CREATE TABLE contact_messages (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id    INT UNSIGNED NULL,
  name       VARCHAR(100) NOT NULL,
  email      VARCHAR(150) NOT NULL,
  subject    VARCHAR(150) NOT NULL,
  message    TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_msg_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- =====================================================
-- SAMPLE DATA
-- All sample accounts use the password:  Password@123
-- =====================================================
INSERT INTO categories (name, slug, icon) VALUES
 ('Web Development',        'web',       'bi-code-slash'),
 ('Graphic Design',         'design',    'bi-palette'),
 ('Mobile Development',     'mobile',    'bi-phone'),
 ('AI & Machine Learning',  'ai',        'bi-robot'),
 ('Video Editing',          'video',     'bi-camera-video'),
 ('Content Writing',        'writing',   'bi-pencil-square'),
 ('Digital Marketing',      'marketing', 'bi-megaphone'),
 ('Online Tutoring',        'tutoring',  'bi-book');

INSERT INTO users (full_name, email, password_hash, role) VALUES
 ('Admin',          'admin@skillbridge.com',  '$2y$10$irQCibyzsC7e2Iu7v6BanOYA1/8FaDUAGBqScuppsrI762az5eADK', 'admin'),
 ('Ayesha Khan',    'client1@skillbridge.com','$2y$10$irQCibyzsC7e2Iu7v6BanOYA1/8FaDUAGBqScuppsrI762az5eADK', 'client'),
 ('Bilal Traders',  'client2@skillbridge.com','$2y$10$irQCibyzsC7e2Iu7v6BanOYA1/8FaDUAGBqScuppsrI762az5eADK', 'client'),
 ('Ali Raza',       'ali@skillbridge.com',    '$2y$10$irQCibyzsC7e2Iu7v6BanOYA1/8FaDUAGBqScuppsrI762az5eADK', 'freelancer'),
 ('Sara Ahmed',     'sara@skillbridge.com',   '$2y$10$irQCibyzsC7e2Iu7v6BanOYA1/8FaDUAGBqScuppsrI762az5eADK', 'freelancer'),
 ('Hamza Malik',    'hamza@skillbridge.com',  '$2y$10$irQCibyzsC7e2Iu7v6BanOYA1/8FaDUAGBqScuppsrI762az5eADK', 'freelancer'),
 ('Fatima Noor',    'fatima@skillbridge.com', '$2y$10$irQCibyzsC7e2Iu7v6BanOYA1/8FaDUAGBqScuppsrI762az5eADK', 'freelancer'),
 ('Usman Tariq',    'usman@skillbridge.com',  '$2y$10$irQCibyzsC7e2Iu7v6BanOYA1/8FaDUAGBqScuppsrI762az5eADK', 'freelancer'),
 ('Zainab Iqbal',   'zainab@skillbridge.com', '$2y$10$irQCibyzsC7e2Iu7v6BanOYA1/8FaDUAGBqScuppsrI762az5eADK', 'freelancer');

INSERT INTO freelancer_profiles (user_id, category_id, headline, bio, skills, rating, reviews_count) VALUES
 (4, 1, 'Web Developer',        'Final-year CS student building fast, responsive websites.',      'React,Node.js,CSS',          4.5, 32),
 (5, 2, 'UI/UX Designer',       'Designs clean interfaces and brand identities for startups.',    'Figma,Branding,Prototyping', 4.5, 28),
 (6, 3, 'Mobile App Developer', 'Builds cross-platform apps with Flutter and Firebase.',          'Flutter,Firebase,Dart',      4.5, 19),
 (7, 4, 'ML Engineer',          'Works on data analysis, chatbots and prediction models.',        'Python,TensorFlow,Pandas',   4.5, 15),
 (8, 5, 'Video Editor',         'Creates engaging edits for YouTube and social media.',           'Premiere,DaVinci,Motion',    4.5, 24),
 (9, 6, 'Content Writer',       'Writes clear, SEO-friendly blogs and website copy.',             'SEO,Blogs,Copywriting',      4.5, 21);

INSERT INTO jobs (client_id, category_id, title, description, skills, budget) VALUES
 (2, 1, 'React E-commerce Website',      'Looking for a frontend developer to create a modern responsive e-commerce website.', 'HTML,CSS,JavaScript', 30000),
 (2, 2, 'Brand Logo & Identity',         'Need a creative designer for a modern startup logo and brand identity.',            'Figma,Branding,UI Design', 15000),
 (3, 3, 'Student Mobile Application',    'Looking for a developer to create a clean university student application.',        'Flutter,Firebase,UI', 45000),
 (3, 4, 'Chatbot for Customer Support',  'Build a simple chatbot that answers common customer questions.',                    'Python,NLP,API', 35000),
 (2, 6, 'Blog Articles for Tech Startup','Write 10 SEO-friendly articles about technology and productivity.',                 'SEO,Writing,Research', 12000),
 (3, 5, 'YouTube Video Editing',         'Edit weekly educational videos with captions and simple motion graphics.',          'Premiere,After Effects,Captions', 20000);

INSERT INTO applications (job_id, freelancer_id, cover_letter, status) VALUES
 (1, 4, 'I have built several React storefronts and can deliver this in 3 weeks.', 'pending'),
 (2, 5, 'Branding is my specialty. I will share a full identity kit in Figma.',     'accepted'),
 (3, 6, 'Flutter + Firebase is exactly my stack. Happy to share previous apps.',   'pending');

INSERT INTO saved_jobs (user_id, job_id) VALUES (4, 1), (4, 3), (5, 2);

INSERT INTO contact_messages (user_id, name, email, subject, message) VALUES
 (NULL, 'Demo Visitor', 'visitor@example.com', 'Question about posting jobs', 'How can a client post a new job on SkillBridge?');
