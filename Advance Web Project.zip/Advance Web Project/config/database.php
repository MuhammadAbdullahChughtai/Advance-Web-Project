<?php
/**
 * Database connection (MySQLi, procedural + prepared statements)
 * Change the values below to match your XAMPP / WAMP / MySQL setup.
 */
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'skillbridge');

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
    http_response_code(500);
    die('<h3 style="font-family:Arial;padding:30px">Database connection failed. '
      . 'Please import <code>database/skillbridge.sql</code> and check <code>config/database.php</code>.</h3>');
}
