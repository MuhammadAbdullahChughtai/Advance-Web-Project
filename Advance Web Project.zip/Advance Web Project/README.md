# SkillBridge - Student Freelance Marketplace
**Advanced Web Programming - Assignment 2 (PHP + MySQL)**

Tech: PHP 8, MySQL/MariaDB (MySQLi prepared statements), HTML5, CSS3, JavaScript, Bootstrap 5, Git/GitHub

## Team
| Name | Roll No |
|------|---------|
| Ayynoor Saeed (Team Lead) | L1S20BSCS0065 |
| Faizan Ahmad Tarar | L1F23BSCS0025 |
| Muhammad Abdullah | L1S24BSCS0184 |
| Azlan Amir | L1F23BSCS0586 |

## How to run (XAMPP / WAMP)
1. Copy this folder into `htdocs` (XAMPP) or `www` (WAMP).
2. Start **Apache** and **MySQL**.
3. Open phpMyAdmin -> *Import* -> choose `database/skillbridge.sql` (it creates the `skillbridge` database, tables and sample data).
4. If your MySQL has a password, edit `config/database.php`.
5. Open `http://localhost/<folder-name>/index.php`

## Demo accounts (password for all: `Password@123`)
| Role | Email |
|------|-------|
| Admin | admin@skillbridge.com |
| Client | client1@skillbridge.com |
| Freelancer | ali@skillbridge.com |

## Folder structure
```
config/database.php        MySQL connection
includes/functions.php     session, CSRF, flash messages, auth + role guards
includes/header.php        shared <head> + dynamic navbar
includes/footer.php        shared footer
database/skillbridge.sql   schema + sample data
admin/                     admin panel (admin role only)
index.php, about.php, find_job.php, freelancer.php, contact.php
login.php, register.php, logout.php
dashboard.php, post_job.php, profile.php, apply_job.php
job_action.php, application_action.php, save_job.php
style.css, script.js
```

## Git workflow (same repository as Assignment 1)
```
git pull
git add .
git commit -m "Assignment 2: PHP + MySQL, auth, roles"
git push origin main
```
