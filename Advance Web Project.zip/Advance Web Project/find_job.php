<?php
$pageTitle = 'Find Jobs';
$activeNav = 'jobs';
require_once 'includes/header.php';

$categories = $conn->query("SELECT slug, name FROM categories ORDER BY id")->fetch_all(MYSQLI_ASSOC);

$jobs = $conn->query(
    "SELECT j.id, j.title, j.description, j.skills, j.budget, c.name AS category, c.slug, c.icon
       FROM jobs j JOIN categories c ON c.id = j.category_id
      WHERE j.status = 'open' ORDER BY j.created_at DESC, j.id DESC"
)->fetch_all(MYSQLI_ASSOC);

/* Which jobs has the current user already saved? */
$saved = [];
if (is_logged_in()) {
    $stmt = $conn->prepare("SELECT job_id FROM saved_jobs WHERE user_id = ?");
    $stmt->bind_param('i', $_SESSION['user_id']);
    $stmt->execute();
    $saved = array_column($stmt->get_result()->fetch_all(MYSQLI_ASSOC), 'job_id');
}
?>
<section class="dark-section">
    <div class="container mt-5">
        <div class="filter-bar reveal">
            <input type="text" id="searchInput" class="form-control" placeholder="Search jobs, skills...">
            <select id="categoryFilter" class="form-select">
                <option value="all">All Categories</option>
                <?php foreach ($categories as $c): ?>
                    <option value="<?= e($c['slug']) ?>"><?= e($c['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="row g-4">
            <?php foreach ($jobs as $job): $isSaved = in_array($job['id'], $saved); ?>
                <div class="col-lg-4 col-md-6 reveal filter-item" data-category="<?= e($job['slug']) ?>">
                    <div class="job-card">
                        <div class="job-top">
                            <div class="job-icon"><i class="bi <?= e($job['icon']) ?>"></i></div>
                            <button class="save-job<?= $isSaved ? ' saved' : '' ?>" data-job="<?= (int)$job['id'] ?>"
                                    data-logged="<?= is_logged_in() ? '1' : '0' ?>" title="Save job">
                                <i class="bi <?= $isSaved ? 'bi-heart-fill' : 'bi-heart' ?>"></i>
                            </button>
                        </div>
                        <span class="job-category"><?= e($job['category']) ?></span>
                        <h4><?= e($job['title']) ?></h4>
                        <p><?= e($job['description']) ?></p>
                        <div class="job-skills">
                            <?php foreach (skill_list($job['skills']) as $s): ?><span><?= e($s) ?></span><?php endforeach; ?>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between">
                            <div><small>Budget</small><h6>Rs. <?= number_format($job['budget']) ?></h6></div>
                            <a href="apply_job.php?id=<?= (int)$job['id'] ?>" class="btn btn-sm btn-primary mt-2">Apply Now</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <p class="no-results" <?= $jobs ? '' : 'style="display:block"' ?>><i class="bi bi-search"></i> No jobs match your search. Try different keywords.</p>
    </div>
</section>
<?php require 'includes/footer.php'; ?>
