<?php
$pageTitle = 'Admin Panel';
$base = '../';
require_once '../includes/functions.php';
require_role('admin');                       // admin only

$count = fn(string $t) => (int)$conn->query("SELECT COUNT(*) FROM $t")->fetch_row()[0];
$tiles = [
    ['Users', $count('users'), 'bi-people'], ['Jobs', $count('jobs'), 'bi-briefcase'],
    ['Applications', $count('applications'), 'bi-file-earmark-text'], ['Messages', $count('contact_messages'), 'bi-envelope'],
];
$users    = $conn->query("SELECT id, full_name, email, role, created_at FROM users ORDER BY id")->fetch_all(MYSQLI_ASSOC);
$jobs     = $conn->query("SELECT j.id, j.title, j.status, j.budget, u.full_name AS client FROM jobs j JOIN users u ON u.id=j.client_id ORDER BY j.id DESC")->fetch_all(MYSQLI_ASSOC);
$messages = $conn->query("SELECT id, name, email, subject, message, created_at FROM contact_messages ORDER BY id DESC")->fetch_all(MYSQLI_ASSOC);

require_once '../includes/header.php';
?>
<section class="dark-section">
    <div class="container mt-5">
        <h2 class="mb-4">Admin Panel</h2>
        <div class="row g-3 mb-4">
            <?php foreach ($tiles as [$label, $n, $icon]): ?>
                <div class="col-6 col-lg-3"><div class="form-card text-center">
                    <i class="bi <?= $icon ?> fs-2" style="color:var(--primary)"></i>
                    <h3 class="mb-0"><?= $n ?></h3><p class="mb-0"><?= $label ?></p></div></div>
            <?php endforeach; ?>
        </div>

        <div class="form-card mb-4">
            <h4 class="mb-3">Users</h4>
            <div class="table-responsive"><table class="table align-middle">
                <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Role</th><th>Joined</th><th></th></tr></thead><tbody>
                <?php foreach ($users as $u): ?>
                    <tr><td><?= (int)$u['id'] ?></td><td><?= e($u['full_name']) ?></td><td><?= e($u['email']) ?></td>
                        <td><span class="badge text-bg-<?= $u['role']==='admin'?'dark':($u['role']==='client'?'info':'primary') ?>"><?= e($u['role']) ?></span></td>
                        <td><?= e(date('d M Y', strtotime($u['created_at']))) ?></td>
                        <td><?php if ($u['role'] !== 'admin'): ?>
                            <form method="post" action="actions.php" onsubmit="return confirm('Delete this user and all their data?')">
                                <?= csrf_field() ?><input type="hidden" name="type" value="user"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
                                <button class="btn btn-sm btn-outline-danger">Delete</button></form><?php endif; ?></td></tr>
                <?php endforeach; ?></tbody></table></div>
        </div>

        <div class="form-card mb-4">
            <h4 class="mb-3">Jobs</h4>
            <div class="table-responsive"><table class="table align-middle">
                <thead><tr><th>#</th><th>Title</th><th>Client</th><th>Budget</th><th>Status</th><th></th></tr></thead><tbody>
                <?php foreach ($jobs as $j): ?>
                    <tr><td><?= (int)$j['id'] ?></td><td><?= e($j['title']) ?></td><td><?= e($j['client']) ?></td>
                        <td>Rs. <?= number_format($j['budget']) ?></td><td><?= e($j['status']) ?></td>
                        <td><form method="post" action="actions.php" onsubmit="return confirm('Delete this job?')">
                            <?= csrf_field() ?><input type="hidden" name="type" value="job"><input type="hidden" name="id" value="<?= (int)$j['id'] ?>">
                            <button class="btn btn-sm btn-outline-danger">Delete</button></form></td></tr>
                <?php endforeach; ?></tbody></table></div>
        </div>

        <div class="form-card">
            <h4 class="mb-3">Contact Messages</h4>
            <?php if (!$messages): ?><p class="mb-0">No messages yet.</p><?php endif; ?>
            <?php foreach ($messages as $m): ?>
                <div class="border rounded-3 p-3 mb-2">
                    <div class="d-flex justify-content-between flex-wrap">
                        <strong><?= e($m['subject']) ?></strong><small><?= e(date('d M Y, H:i', strtotime($m['created_at']))) ?></small></div>
                    <small><?= e($m['name']) ?> · <?= e($m['email']) ?></small>
                    <p class="mb-0 mt-1" style="white-space:pre-line"><?= e($m['message']) ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php require '../includes/footer.php'; ?>
