<?php
$pageTitle = 'Contact';
$activeNav = 'contact';
require_once 'includes/functions.php';

$errors = [];
$old = [
    'name'    => $_SESSION['full_name'] ?? '',
    'email'   => $_SESSION['email'] ?? '',
    'subject' => trim($_GET['subject'] ?? ''),
    'message' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old = [
        'name'    => trim($_POST['name'] ?? ''),
        'email'   => trim($_POST['email'] ?? ''),
        'subject' => trim($_POST['subject'] ?? ''),
        'message' => trim($_POST['message'] ?? ''),
    ];

    /* ---- Server-side validation ---- */
    if (!csrf_valid())                                        $errors[] = 'Invalid form token. Please refresh and try again.';
    if (mb_strlen($old['name']) < 3 || mb_strlen($old['name']) > 100) $errors['name'] = 'Name must be 3 to 100 characters.';
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL))   $errors['email'] = 'Please enter a valid email address.';
    if (mb_strlen($old['subject']) < 3 || mb_strlen($old['subject']) > 150) $errors['subject'] = 'Subject must be 3 to 150 characters.';
    if (mb_strlen($old['message']) < 10)                      $errors['message'] = 'Message must be at least 10 characters.';

    if (!$errors) {
        $uid  = $_SESSION['user_id'] ?? null;
        $stmt = $conn->prepare("INSERT INTO contact_messages (user_id, name, email, subject, message) VALUES (?,?,?,?,?)");
        $stmt->bind_param('issss', $uid, $old['name'], $old['email'], $old['subject'], $old['message']);
        $stmt->execute();
        set_flash('success', 'Thank you! Your message has been sent.');
        redirect('contact.php');          // Post/Redirect/Get
    }
}

require_once 'includes/header.php';
function field_error(array $errors, string $key): string
{
    return isset($errors[$key]) ? '<div class="invalid-feedback d-block">' . e($errors[$key]) . '</div>' : '';
}
?>
<section class="dark-section">
    <div class="container mt-5">
        <div class="row g-5">
            <div class="col-lg-5 reveal-left">
                <h2 class="mb-4">Contact Information</h2>
                <div class="contact-item"><div class="category-icon"><i class="bi bi-geo-alt"></i></div><div><h5>Address</h5><p>University Road, Lahore, Pakistan</p></div></div>
                <div class="contact-item"><div class="category-icon"><i class="bi bi-envelope"></i></div><div><h5>Email</h5><p>support@skillbridge.com</p></div></div>
                <div class="contact-item"><div class="category-icon"><i class="bi bi-telephone"></i></div><div><h5>Phone</h5><p>+92 300 1234567</p></div></div>
                <div class="contact-item"><div class="category-icon"><i class="bi bi-clock"></i></div><div><h5>Working Hours</h5><p>Mon - Fri, 9:00 AM - 6:00 PM</p></div></div>
            </div>

            <div class="col-lg-7 reveal-right">
                <div class="form-card">
                    <h4 class="mb-4">Send us a message</h4>

                    <?php if (isset($errors[0])): ?><div class="alert alert-danger"><?= e($errors[0]) ?></div><?php endif; ?>

                    <form method="post" action="contact.php" novalidate>
                        <?= csrf_field() ?>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label for="name">Full name</label>
                                <input type="text" id="name" name="name" class="form-control <?= isset($errors['name']) ? 'is-invalid' : '' ?>" value="<?= e($old['name']) ?>" required>
                                <?= field_error($errors, 'name') ?>
                            </div>
                            <div class="col-md-6">
                                <label for="email">Email</label>
                                <input type="email" id="email" name="email" class="form-control <?= isset($errors['email']) ? 'is-invalid' : '' ?>" value="<?= e($old['email']) ?>" required>
                                <?= field_error($errors, 'email') ?>
                            </div>
                            <div class="col-12">
                                <label for="subject">Subject</label>
                                <input type="text" id="subject" name="subject" class="form-control <?= isset($errors['subject']) ? 'is-invalid' : '' ?>" value="<?= e($old['subject']) ?>" required>
                                <?= field_error($errors, 'subject') ?>
                            </div>
                            <div class="col-12">
                                <label for="message">Message</label>
                                <textarea id="message" name="message" rows="5" class="form-control <?= isset($errors['message']) ? 'is-invalid' : '' ?>" required><?= e($old['message']) ?></textarea>
                                <?= field_error($errors, 'message') ?>
                            </div>
                            <div class="col-12"><button type="submit" class="btn btn-primary btn-lg px-5">Send Message <i class="bi bi-send"></i></button></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php require 'includes/footer.php'; ?>
