<?php
$pageTitle = 'Student Freelance Marketplace';
$activeNav = 'home';
require_once 'includes/header.php';

/* Dynamic data from MySQL */
$categories = $conn->query(
    "SELECT c.name, c.icon, COUNT(j.id) AS total
       FROM categories c
       LEFT JOIN jobs j ON j.category_id = c.id AND j.status = 'open'
   GROUP BY c.id ORDER BY c.id"
)->fetch_all(MYSQLI_ASSOC);

$featured = $conn->query(
    "SELECT j.id, j.title, j.description, j.skills, j.budget, c.name AS category, c.icon
       FROM jobs j JOIN categories c ON c.id = j.category_id
      WHERE j.status = 'open' ORDER BY j.created_at DESC, j.id DESC LIMIT 3"
)->fetch_all(MYSQLI_ASSOC);

$stats = [
    'students' => (int)$conn->query("SELECT COUNT(*) FROM users WHERE role='freelancer'")->fetch_row()[0],
    'jobs'     => (int)$conn->query("SELECT COUNT(*) FROM jobs")->fetch_row()[0],
    'projects' => (int)$conn->query("SELECT COUNT(*) FROM applications")->fetch_row()[0],
];
?>

<!-- ================= HERO ================= -->
<section class="hero">
    <div class="hero-shape shape-one"></div>
    <div class="hero-shape shape-two"></div>
    <div class="container">
        <div class="row align-items-center min-vh-100">
            <div class="col-lg-6 hero-content reveal-left">
                <div class="hero-badge"><i class="bi bi-stars"></i> Built for Students. Powered by Skills.</div>
                <h1>Turn Your Skills Into <span>Real Opportunities.</span></h1>
                <p>SkillBridge connects talented university students with clients looking for fresh ideas,
                   technical skills and affordable freelance services.</p>

                <div class="hero-buttons">
                    <a href="find_job.php" class="btn btn-primary btn-lg">Find Jobs <i class="bi bi-arrow-right"></i></a>
                    <a href="freelancer.php" class="btn btn-outline-dark btn-lg">Find Talent</a>
                </div>

                <div class="hero-stats">
                    <div><h4 class="counter" data-target="<?= $stats['students'] ?>">0</h4><p>Students</p></div>
                    <div><h4 class="counter" data-target="<?= $stats['jobs'] ?>">0</h4><p>Jobs</p></div>
                    <div><h4 class="counter" data-target="<?= $stats['projects'] ?>">0</h4><p>Applications</p></div>
                </div>
            </div>

            <div class="col-lg-6 text-center reveal-right">
                <div class="hero-card">
                    <div class="floating-icon icon-code"><i class="bi bi-code-slash"></i></div>
                    <div class="floating-icon icon-design"><i class="bi bi-palette"></i></div>
                    <div class="floating-icon icon-laptop"><i class="bi bi-laptop"></i></div>
                    <div class="profile-circle"><i class="bi bi-person-workspace"></i></div>
                    <h3>Find Your Next Opportunity</h3>
                    <p>Connect • Collaborate • Grow</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ================= CATEGORIES ================= -->
<section class="section-padding categories">
    <div class="container">
        <div class="section-title reveal">
            <span>EXPLORE</span>
            <h2>Popular Categories</h2>
            <p>Discover opportunities based on your skills and interests.</p>
        </div>
        <div class="row g-4">
            <?php foreach ($categories as $cat): ?>
                <div class="col-lg-3 col-md-6 reveal">
                    <div class="category-card">
                        <div class="category-icon"><i class="bi <?= e($cat['icon']) ?>"></i></div>
                        <h5><?= e($cat['name']) ?></h5>
                        <p><?= (int)$cat['total'] ?> Open Job<?= $cat['total'] == 1 ? '' : 's' ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ================= FEATURED JOBS ================= -->
<section class="section-padding jobs-section">
    <div class="container">
        <div class="section-title reveal">
            <span>OPPORTUNITIES</span>
            <h2>Featured Jobs</h2>
            <p>Find projects that match your skills.</p>
        </div>
        <div class="row g-4">
            <?php foreach ($featured as $job): ?>
                <div class="col-lg-4 col-md-6 reveal">
                    <div class="job-card">
                        <div class="job-top">
                            <div class="job-icon"><i class="bi <?= e($job['icon']) ?>"></i></div>
                        </div>
                        <span class="job-category"><?= e($job['category']) ?></span>
                        <h4><?= e($job['title']) ?></h4>
                        <p><?= e($job['description']) ?></p>
                        <div class="job-skills">
                            <?php foreach (skill_list($job['skills']) as $s): ?><span><?= e($s) ?></span><?php endforeach; ?>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between">
                            <div><small>Budget</small><h6>Rs. <?= number_format($job['budget']) ?></h6></div>
                            <a href="apply_job.php?id=<?= (int)$job['id'] ?>" class="btn btn-sm btn-primary mt-2">View Job</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
            <?php if (!$featured): ?><p class="text-center text-muted">No jobs posted yet.</p><?php endif; ?>
        </div>
        <div class="text-center mt-5 reveal">
            <a href="find_job.php" class="anchor btn btn-outline-primary px-5 py-3">Browse All Jobs</a>
        </div>
    </div>
</section>

<!-- ================= HOW IT WORKS ================= -->
<section class="section-padding how-section">
    <div class="container">
        <div class="section-title reveal"><span>SIMPLE PROCESS</span><h2>How SkillBridge Works</h2></div>
        <div class="row g-4 text-center">
            <div class="col-lg-4 reveal"><div class="process-card">
                <div class="process-number">01</div><i class="bi bi-person-plus"></i>
                <h4><a href="register.php">Create Your Profile</a></h4>
                <p>Sign up as a freelancer or client and create your professional profile.</p>
            </div></div>
            <div class="col-lg-4 reveal"><div class="process-card">
                <div class="process-number">02</div><i class="bi bi-search"></i>
                <h4>Find Opportunities</h4>
                <p>Browse freelance jobs or discover talented students for your project.</p>
            </div></div>
            <div class="col-lg-4 reveal"><div class="process-card">
                <div class="process-number">03</div><i class="bi bi-rocket-takeoff"></i>
                <h4>Work &amp; Grow</h4>
                <p>Collaborate, complete projects and build real-world experience.</p>
            </div></div>
        </div>
    </div>
</section>

<!-- ================= CTA ================= -->
<section class="cta-section">
    <div class="container">
        <div class="cta-box reveal">
            <div>
                <h2>Ready to turn your skills into opportunities?</h2>
                <p>Join SkillBridge and start building your professional journey today.</p>
            </div>
            <a href="<?= is_logged_in() ? e(dashboard_url()) : 'register.php' ?>" class="btn btn-light btn-lg">
                <?= is_logged_in() ? 'Go to Dashboard' : 'Get Started' ?> <i class="bi bi-arrow-right"></i>
            </a>
        </div>
    </div>
</section>

<div class="mt-5"></div>
<?php require 'includes/footer.php'; ?>
